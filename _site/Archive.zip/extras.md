---
layout: default
title: About
permalink: /extras
---
# Extras

## Development Art

Here are some sketches I did while writing Red Ants.
x x x x x

## Comic Resources
I cobbled this website together using [the Bootstrap framework](http://getbootstrap.com/) and [Jekyll](https://jekyllrb.com/), a static site generator. You can download the comic website code here.

You don't need to link back to me on your website. I just want you to have a nice website and make some guud comix.

[@ me](http://twitter.com/peahat) if you need help

Thank you!
