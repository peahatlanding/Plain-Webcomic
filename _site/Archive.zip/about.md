---
layout: default
title: About
permalink: /about
---
# About the Comic

Nulla scelerisque massa erat, ac fermentum tellus luctus a. Quisque turpis massa, scelerisque non mauris ac, mattis vehicula magna. Nunc viverra diam quis est dictum consequat. Quisque non sapien lectus. Integer a ligula ac velit euismod lobortis. Nullam commodo orci a magna varius, sed laoreet nulla auctor.

Curabitur auctor nulla eros, et placerat sapien auctor eget. Duis sed enim est. Vivamus sapien lectus, venenatis nec sapien eget, pharetra consectetur lorem. Nunc nec purus suscipit, suscipit diam non, malesuada lorem.

[Red Ant Twitter](http://twitter.com/redantcomic)

[Red Ant Tumblr](http://redantcomic.tumblr.com)

[Author Twitter](http://twitter.com/peahat)
